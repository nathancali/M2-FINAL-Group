﻿namespace PartialForm
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            Displaybtn = new Button();
            dataGridView1 = new DataGridView();
            Addbtn = new Button();
            nameTextBox = new TextBox();
            codeTextBox = new TextBox();
            brandTextBox = new TextBox();
            unitPriceTextBox = new TextBox();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            Deletebtn = new Button();
            Idtextbox = new TextBox();
            Updatebtn = new Button();
            NameUpTB = new TextBox();
            CodeUpTB = new TextBox();
            BrandUpTB = new TextBox();
            UnitPriceUpTB = new TextBox();
            Searchbtn = new Button();
            NameUpLbl = new Label();
            CodeUpLbl = new Label();
            BrandUpLbl = new Label();
            UnitPriceUpLbl = new Label();
            label5 = new Label();
            label6 = new Label();
            label7 = new Label();
            button1 = new Button();
            button2 = new Button();
            label8 = new Label();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            SuspendLayout();
            // 
            // Displaybtn
            // 
            Displaybtn.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            Displaybtn.Location = new Point(267, 200);
            Displaybtn.Name = "Displaybtn";
            Displaybtn.Size = new Size(94, 29);
            Displaybtn.TabIndex = 1;
            Displaybtn.Text = "Display";
            Displaybtn.UseVisualStyleBackColor = true;
            Displaybtn.Click += button1_Click;
            // 
            // dataGridView1
            // 
            dataGridView1.AllowUserToAddRows = false;
            dataGridView1.AllowUserToDeleteRows = false;
            dataGridView1.AllowUserToOrderColumns = true;
            dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Location = new Point(0, 228);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.ReadOnly = true;
            dataGridView1.RowHeadersWidth = 51;
            dataGridView1.RowTemplate.Height = 29;
            dataGridView1.Size = new Size(825, 348);
            dataGridView1.TabIndex = 2;
            // 
            // Addbtn
            // 
            Addbtn.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            Addbtn.Location = new Point(94, 201);
            Addbtn.Name = "Addbtn";
            Addbtn.Size = new Size(125, 28);
            Addbtn.TabIndex = 3;
            Addbtn.Text = "Add";
            Addbtn.UseVisualStyleBackColor = true;
            Addbtn.Click += button2_Click_1;
            // 
            // nameTextBox
            // 
            nameTextBox.Location = new Point(94, 41);
            nameTextBox.Name = "nameTextBox";
            nameTextBox.Size = new Size(125, 27);
            nameTextBox.TabIndex = 5;
            nameTextBox.TextChanged += textBox1_TextChanged;
            // 
            // codeTextBox
            // 
            codeTextBox.CharacterCasing = CharacterCasing.Lower;
            codeTextBox.Location = new Point(94, 77);
            codeTextBox.Name = "codeTextBox";
            codeTextBox.Size = new Size(125, 27);
            codeTextBox.TabIndex = 6;
            // 
            // brandTextBox
            // 
            brandTextBox.Location = new Point(94, 113);
            brandTextBox.Name = "brandTextBox";
            brandTextBox.Size = new Size(125, 27);
            brandTextBox.TabIndex = 7;
            // 
            // unitPriceTextBox
            // 
            unitPriceTextBox.Location = new Point(94, 150);
            unitPriceTextBox.Name = "unitPriceTextBox";
            unitPriceTextBox.Size = new Size(125, 27);
            unitPriceTextBox.TabIndex = 8;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI Semilight", 9F, FontStyle.Regular, GraphicsUnit.Point);
            label1.Location = new Point(16, 44);
            label1.Name = "label1";
            label1.Size = new Size(49, 20);
            label1.TabIndex = 9;
            label1.Text = "Name";
            label1.Click += label1_Click;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI Semilight", 9F, FontStyle.Regular, GraphicsUnit.Point);
            label2.Location = new Point(16, 77);
            label2.Name = "label2";
            label2.Size = new Size(44, 20);
            label2.TabIndex = 10;
            label2.Text = "Code";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI Semilight", 9F, FontStyle.Regular, GraphicsUnit.Point);
            label3.Location = new Point(16, 116);
            label3.Name = "label3";
            label3.Size = new Size(47, 20);
            label3.TabIndex = 11;
            label3.Text = "Brand";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI Semilight", 9F, FontStyle.Regular, GraphicsUnit.Point);
            label4.Location = new Point(11, 153);
            label4.Name = "label4";
            label4.Size = new Size(70, 20);
            label4.TabIndex = 12;
            label4.Text = "Unit Price";
            // 
            // Deletebtn
            // 
            Deletebtn.Enabled = false;
            Deletebtn.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            Deletebtn.Location = new Point(551, 117);
            Deletebtn.Name = "Deletebtn";
            Deletebtn.Size = new Size(125, 47);
            Deletebtn.TabIndex = 13;
            Deletebtn.Text = "Delete";
            Deletebtn.UseVisualStyleBackColor = true;
            Deletebtn.Click += button3_Click;
            // 
            // Idtextbox
            // 
            Idtextbox.Font = new Font("Segoe UI Light", 9F, FontStyle.Regular, GraphicsUnit.Point);
            Idtextbox.Location = new Point(448, 201);
            Idtextbox.Name = "Idtextbox";
            Idtextbox.Size = new Size(352, 27);
            Idtextbox.TabIndex = 14;
            Idtextbox.Text = "ID";
            Idtextbox.TextAlign = HorizontalAlignment.Center;
            Idtextbox.TextChanged += textBox1_TextChanged_1;
            // 
            // Updatebtn
            // 
            Updatebtn.Enabled = false;
            Updatebtn.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            Updatebtn.Location = new Point(675, 118);
            Updatebtn.Name = "Updatebtn";
            Updatebtn.Size = new Size(125, 46);
            Updatebtn.TabIndex = 16;
            Updatebtn.Text = "Update";
            Updatebtn.UseVisualStyleBackColor = true;
            Updatebtn.Click += button4_Click;
            // 
            // NameUpTB
            // 
            NameUpTB.Location = new Point(274, 48);
            NameUpTB.Name = "NameUpTB";
            NameUpTB.ReadOnly = true;
            NameUpTB.Size = new Size(125, 27);
            NameUpTB.TabIndex = 17;
            NameUpTB.TextChanged += NameUpTB_TextChanged;
            // 
            // CodeUpTB
            // 
            CodeUpTB.Location = new Point(407, 48);
            CodeUpTB.Name = "CodeUpTB";
            CodeUpTB.ReadOnly = true;
            CodeUpTB.Size = new Size(125, 27);
            CodeUpTB.TabIndex = 18;
            // 
            // BrandUpTB
            // 
            BrandUpTB.Location = new Point(542, 48);
            BrandUpTB.Name = "BrandUpTB";
            BrandUpTB.ReadOnly = true;
            BrandUpTB.Size = new Size(125, 27);
            BrandUpTB.TabIndex = 19;
            // 
            // UnitPriceUpTB
            // 
            UnitPriceUpTB.Location = new Point(675, 48);
            UnitPriceUpTB.Name = "UnitPriceUpTB";
            UnitPriceUpTB.ReadOnly = true;
            UnitPriceUpTB.Size = new Size(125, 27);
            UnitPriceUpTB.TabIndex = 20;
            // 
            // Searchbtn
            // 
            Searchbtn.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            Searchbtn.Location = new Point(360, 200);
            Searchbtn.Name = "Searchbtn";
            Searchbtn.Size = new Size(94, 29);
            Searchbtn.TabIndex = 21;
            Searchbtn.Text = "Search";
            Searchbtn.UseVisualStyleBackColor = true;
            Searchbtn.Click += button5_Click;
            // 
            // NameUpLbl
            // 
            NameUpLbl.AutoSize = true;
            NameUpLbl.Font = new Font("Segoe UI Semilight", 9F, FontStyle.Regular, GraphicsUnit.Point);
            NameUpLbl.Location = new Point(305, 21);
            NameUpLbl.Name = "NameUpLbl";
            NameUpLbl.Size = new Size(49, 20);
            NameUpLbl.TabIndex = 22;
            NameUpLbl.Text = "Name";
            NameUpLbl.Visible = false;
            NameUpLbl.Click += label6_Click;
            // 
            // CodeUpLbl
            // 
            CodeUpLbl.AutoSize = true;
            CodeUpLbl.Font = new Font("Segoe UI Semilight", 9F, FontStyle.Regular, GraphicsUnit.Point);
            CodeUpLbl.Location = new Point(438, 21);
            CodeUpLbl.Name = "CodeUpLbl";
            CodeUpLbl.Size = new Size(44, 20);
            CodeUpLbl.TabIndex = 23;
            CodeUpLbl.Text = "Code";
            CodeUpLbl.Visible = false;
            // 
            // BrandUpLbl
            // 
            BrandUpLbl.AutoSize = true;
            BrandUpLbl.Font = new Font("Segoe UI Semilight", 9F, FontStyle.Regular, GraphicsUnit.Point);
            BrandUpLbl.Location = new Point(577, 21);
            BrandUpLbl.Name = "BrandUpLbl";
            BrandUpLbl.Size = new Size(47, 20);
            BrandUpLbl.TabIndex = 24;
            BrandUpLbl.Text = "Brand";
            BrandUpLbl.Visible = false;
            // 
            // UnitPriceUpLbl
            // 
            UnitPriceUpLbl.AutoSize = true;
            UnitPriceUpLbl.Font = new Font("Segoe UI Semilight", 9F, FontStyle.Regular, GraphicsUnit.Point);
            UnitPriceUpLbl.Location = new Point(697, 21);
            UnitPriceUpLbl.Name = "UnitPriceUpLbl";
            UnitPriceUpLbl.Size = new Size(70, 20);
            UnitPriceUpLbl.TabIndex = 25;
            UnitPriceUpLbl.Text = "Unit Price";
            UnitPriceUpLbl.Visible = false;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point);
            label5.ForeColor = SystemColors.ControlDarkDark;
            label5.Location = new Point(236, 5);
            label5.Name = "label5";
            label5.Size = new Size(19, 220);
            label5.TabIndex = 26;
            label5.Text = "||\r\n||\r\n||\r\n||\r\n||\r\n||\r\n||\r\n||\r\n||\r\n||\r\n||";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Segoe UI Light", 9F, FontStyle.Regular, GraphicsUnit.Point);
            label6.Location = new Point(277, 104);
            label6.Name = "label6";
            label6.Size = new Size(192, 60);
            label6.TabIndex = 27;
            label6.Text = "Note: To enable Delete and \r\nUpdate, Enter an appropriate \r\nID in the Search Bar.";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point);
            label7.ForeColor = SystemColors.ControlDarkDark;
            label7.Location = new Point(806, 5);
            label7.Name = "label7";
            label7.Size = new Size(19, 220);
            label7.TabIndex = 28;
            label7.Text = "||\r\n||\r\n||\r\n||\r\n||\r\n||\r\n||\r\n||\r\n||\r\n||\r\n||";
            // 
            // button1
            // 
            button1.Location = new Point(967, 492);
            button1.Name = "button1";
            button1.Size = new Size(94, 68);
            button1.TabIndex = 29;
            button1.Text = "Logout";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click_1;
            // 
            // button2
            // 
            button2.Location = new Point(845, 492);
            button2.Name = "button2";
            button2.Size = new Size(94, 68);
            button2.TabIndex = 30;
            button2.Text = "Register";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click_2;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Dock = DockStyle.Right;
            label8.Image = Properties.Resources.bannerform1_project;
            label8.Location = new Point(826, 0);
            label8.Name = "label8";
            label8.Size = new Size(249, 600);
            label8.TabIndex = 31;
            label8.Text = resources.GetString("label8.Text");
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.LightSlateGray;
            ClientSize = new Size(1075, 576);
            Controls.Add(button2);
            Controls.Add(button1);
            Controls.Add(label7);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(UnitPriceUpLbl);
            Controls.Add(BrandUpLbl);
            Controls.Add(CodeUpLbl);
            Controls.Add(NameUpLbl);
            Controls.Add(Searchbtn);
            Controls.Add(UnitPriceUpTB);
            Controls.Add(BrandUpTB);
            Controls.Add(CodeUpTB);
            Controls.Add(NameUpTB);
            Controls.Add(Updatebtn);
            Controls.Add(Idtextbox);
            Controls.Add(Deletebtn);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(unitPriceTextBox);
            Controls.Add(brandTextBox);
            Controls.Add(codeTextBox);
            Controls.Add(nameTextBox);
            Controls.Add(Addbtn);
            Controls.Add(dataGridView1);
            Controls.Add(Displaybtn);
            Controls.Add(label8);
            Name = "Form1";
            Text = "Stockly";
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button Displaybtn;
        private DataGridView dataGridView1;
        private Button Addbtn;
        private TextBox nameTextBox;
        private TextBox codeTextBox;
        private TextBox brandTextBox;
        private TextBox unitPriceTextBox;
        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private Button Deletebtn;
        private TextBox Idtextbox;
        private Button Updatebtn;
        private TextBox NameUpTB;
        private TextBox CodeUpTB;
        private TextBox BrandUpTB;
        private TextBox UnitPriceUpTB;
        private Button Searchbtn;
        private Label NameUpLbl;
        private Label CodeUpLbl;
        private Label BrandUpLbl;
        private Label UnitPriceUpLbl;
        private Label label5;
        private Label label6;
        private Label label7;
        private Button button1;
        private Button button2;
        private Label label8;
    }
}