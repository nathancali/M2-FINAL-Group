﻿namespace PartialForm
{
    partial class RegisterForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(RegisterForm));
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            UsernameTB = new TextBox();
            FirstnameTB = new TextBox();
            LastnameTB = new TextBox();
            PasswordTB = new TextBox();
            button1 = new Button();
            button2 = new Button();
            dataGridView1 = new DataGridView();
            IdTB = new TextBox();
            button3 = new Button();
            button4 = new Button();
            label5 = new Label();
            button5 = new Button();
            label6 = new Label();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(11, 82);
            label1.Name = "label1";
            label1.Size = new Size(75, 20);
            label1.TabIndex = 0;
            label1.Text = "Username";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(11, 132);
            label2.Name = "label2";
            label2.Size = new Size(80, 20);
            label2.TabIndex = 1;
            label2.Text = "First Name";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(11, 183);
            label3.Name = "label3";
            label3.Size = new Size(79, 20);
            label3.TabIndex = 2;
            label3.Text = "Last Name";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(11, 241);
            label4.Name = "label4";
            label4.Size = new Size(70, 20);
            label4.TabIndex = 3;
            label4.Text = "Password";
            // 
            // UsernameTB
            // 
            UsernameTB.Location = new Point(116, 79);
            UsernameTB.Name = "UsernameTB";
            UsernameTB.Size = new Size(260, 27);
            UsernameTB.TabIndex = 4;
            // 
            // FirstnameTB
            // 
            FirstnameTB.Location = new Point(116, 129);
            FirstnameTB.Name = "FirstnameTB";
            FirstnameTB.Size = new Size(260, 27);
            FirstnameTB.TabIndex = 5;
            // 
            // LastnameTB
            // 
            LastnameTB.Location = new Point(116, 180);
            LastnameTB.Name = "LastnameTB";
            LastnameTB.Size = new Size(260, 27);
            LastnameTB.TabIndex = 6;
            // 
            // PasswordTB
            // 
            PasswordTB.Location = new Point(116, 238);
            PasswordTB.Name = "PasswordTB";
            PasswordTB.Size = new Size(260, 27);
            PasswordTB.TabIndex = 7;
            // 
            // button1
            // 
            button1.Location = new Point(151, 298);
            button1.Name = "button1";
            button1.Size = new Size(94, 29);
            button1.TabIndex = 8;
            button1.Text = "Register";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // button2
            // 
            button2.Location = new Point(22, 298);
            button2.Name = "button2";
            button2.Size = new Size(94, 29);
            button2.TabIndex = 9;
            button2.Text = "Back";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click;
            // 
            // dataGridView1
            // 
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Location = new Point(398, 70);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.RowHeadersWidth = 51;
            dataGridView1.RowTemplate.Height = 29;
            dataGridView1.Size = new Size(490, 284);
            dataGridView1.TabIndex = 10;
            // 
            // IdTB
            // 
            IdTB.Location = new Point(598, 23);
            IdTB.Name = "IdTB";
            IdTB.Size = new Size(278, 27);
            IdTB.TabIndex = 11;
            // 
            // button3
            // 
            button3.Location = new Point(398, 22);
            button3.Name = "button3";
            button3.Size = new Size(94, 29);
            button3.TabIndex = 12;
            button3.Text = "Delete";
            button3.UseVisualStyleBackColor = true;
            button3.Click += button3_Click;
            // 
            // button4
            // 
            button4.Location = new Point(498, 22);
            button4.Name = "button4";
            button4.Size = new Size(94, 29);
            button4.TabIndex = 13;
            button4.Text = "Search";
            button4.UseVisualStyleBackColor = true;
            button4.Click += button4_Click;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Segoe UI Symbol", 22.2F, FontStyle.Bold, GraphicsUnit.Point);
            label5.Location = new Point(59, 16);
            label5.Name = "label5";
            label5.Size = new Size(255, 50);
            label5.TabIndex = 14;
            label5.Text = "Register Here";
            label5.Click += label5_Click;
            // 
            // button5
            // 
            button5.Location = new Point(282, 298);
            button5.Name = "button5";
            button5.Size = new Size(94, 29);
            button5.TabIndex = 15;
            button5.Text = "Display";
            button5.UseVisualStyleBackColor = true;
            button5.Click += button5_Click;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Dock = DockStyle.Right;
            label6.Font = new Font("Segoe UI", 7.8F, FontStyle.Regular, GraphicsUnit.Point);
            label6.Image = (Image)resources.GetObject("label6.Image");
            label6.Location = new Point(889, 0);
            label6.Name = "label6";
            label6.Size = new Size(248, 391);
            label6.TabIndex = 16;
            label6.Text = resources.GetString("label6.Text");
            // 
            // RegisterForm
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.LightSlateGray;
            ClientSize = new Size(1137, 353);
            Controls.Add(label6);
            Controls.Add(button5);
            Controls.Add(label5);
            Controls.Add(button4);
            Controls.Add(button3);
            Controls.Add(IdTB);
            Controls.Add(dataGridView1);
            Controls.Add(button2);
            Controls.Add(button1);
            Controls.Add(PasswordTB);
            Controls.Add(LastnameTB);
            Controls.Add(FirstnameTB);
            Controls.Add(UsernameTB);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Name = "RegisterForm";
            Text = "Stockly";
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private TextBox UsernameTB;
        private TextBox FirstnameTB;
        private TextBox LastnameTB;
        private TextBox PasswordTB;
        private Button button1;
        private Button button2;
        private DataGridView dataGridView1;
        private TextBox IdTB;
        private Button button3;
        private Button button4;
        private Label label5;
        private Button button5;
        private Label label6;
    }
}