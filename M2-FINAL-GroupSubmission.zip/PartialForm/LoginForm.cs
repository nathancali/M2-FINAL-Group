﻿using RestSharp;
using System;
using System.Collections.Generic;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using DataLibrary.Data;
using DataLibrary.Database;
using DataLibrary.Models;
using Microsoft.Extensions.Configuration;
using System.Data.SqlClient;
using System.Data;
using System.Diagnostics;

namespace PartialForm
{
    public partial class LoginForm : Form
    {
        public LoginForm()
        {
            InitializeComponent();
        }



        private void button1_Click(object sender, EventArgs e)
        {
            // Check if username and password are not empty
            if (string.IsNullOrEmpty(UsernameTB.Text) || string.IsNullOrEmpty(PasswordTB.Text))
            {
                MessageBox.Show("Please enter both username and password.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // Create JSON request body
            var json = new { Username = UsernameTB.Text, Password = PasswordTB.Text };

            // Send HTTP request and get response
            var client = new RestClient("https://localhost:7120/api/User/login");
            var request = new RestRequest(Method.POST);
            request.AddJsonBody(json);
            var response = client.Execute(request);

            // Check if response is successful and the result is true
            if (response.IsSuccessful && response.Content == "true")
            {
                MessageBox.Show("Login successful!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                Form1 f = new Form1();
                f.Show();
                this.Hide();

                // TODO: Navigate to the main form
            }
            else
            {
                MessageBox.Show("Invalid username or password.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }
    }
}
