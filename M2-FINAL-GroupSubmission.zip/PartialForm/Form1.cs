using RestSharp;
using System;
using System.Collections.Generic;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using DataLibrary.Data;
using DataLibrary.Database;
using DataLibrary.Models;
using Microsoft.Extensions.Configuration;
using System.Data.SqlClient;
using System.Data;

namespace PartialForm
{
    public partial class Form1 : Form
    {
        private const string BaseUrl = "https://localhost:7120/api/Item";
        private List<InvModel> _items = new List<InvModel>();
        public Form1()
        {
            InitializeComponent();
        }

        private void MainForm_Load(object sender, EventArgs e)
        {
            LoadItems();
        }


        static SqlData GetConnection()
        {
            var builder = new ConfigurationBuilder()
                .SetBasePath(Directory.GetCurrentDirectory())
                .AddJsonFile("appsettings.json");

            IConfiguration config = builder.Build();
            ISqlDataAccess dbAccess = new SqlDataAccess(config);
            SqlData db = new SqlData(dbAccess);

            return db;
        }




        private void LoadItems()
        {
            var client = new RestClient("https://localhost:7120/api/Item");
            var request = new RestRequest(Method.GET);
            var response = client.Execute<List<InvModel>>(request);

            if (response.IsSuccessful)
            {
                dataGridView1.DataSource = response.Data;
            }
            else
            {
                MessageBox.Show("Failed to load items", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            LoadItems();

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            // Validate textboxes
            if (string.IsNullOrWhiteSpace(nameTextBox.Text) || string.IsNullOrWhiteSpace(codeTextBox.Text) || string.IsNullOrWhiteSpace(brandTextBox.Text)
                || string.IsNullOrWhiteSpace(unitPriceTextBox.Text))
            {
                MessageBox.Show("Please enter all fields.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            decimal unitPrice;
            if (!decimal.TryParse(unitPriceTextBox.Text, out unitPrice))
            {
                MessageBox.Show("Please enter a valid unit price.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            InvModel newItem = new InvModel
            {
                Name = nameTextBox.Text,
                Code = int.Parse(codeTextBox.Text),
                Brand = brandTextBox.Text,
                UnitPrice = decimal.Parse(unitPriceTextBox.Text)
            };

            // Call the AddItem API method using RestSharp
            var client = new RestClient("https://localhost:7120/api/Item/add");
            var request = new RestRequest(Method.POST);
            request.AddJsonBody(newItem);
            var response = client.Execute(request);

            if (response.IsSuccessful)
            {
                // Reload items in data grid view
                LoadItems();
                MessageBox.Show("Item added successfully.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                MessageBox.Show("Failed to add item.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }


        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            // Validate ID textbox
            if (string.IsNullOrWhiteSpace(Idtextbox.Text))
            {
                MessageBox.Show("Please enter an ID.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            int id;
            if (!int.TryParse(Idtextbox.Text, out id))
            {
                MessageBox.Show("Please enter a valid ID.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            string connectionString = "Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=InvDB;Integrated Security=True;Connect Timeout=60;";
            string query = $"SELECT COUNT(*) FROM Inventory WHERE id = {id}";
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand command = new SqlCommand(query, connection);
                try
                {
                    connection.Open();
                    int count = (int)command.ExecuteScalar();
                    if (count == 0)
                    {
                        MessageBox.Show($"ID {id} not found in the database.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
            }


            // Call the DeleteItem API method using RestSharp
            var client = new RestClient($"https://localhost:7120/api/Item/delete/{id}");
            var request = new RestRequest(Method.DELETE);
            var response = client.Execute(request);

            if (response.IsSuccessful)
            {
                // Reload items in data grid view
                LoadItems();
                MessageBox.Show("Item deleted successfully.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                MessageBox.Show("Failed to delete item.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void textBox1_TextChanged_1(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(Idtextbox.Text))
            {
                MessageBox.Show("Please enter an ID.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            int id;
            if (!int.TryParse(Idtextbox.Text, out id))
            {
                MessageBox.Show("Please enter a valid ID.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            string connectionString = "Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=InvDB;Integrated Security=True;Connect Timeout=60;";
            string query = $"SELECT COUNT(*) FROM Inventory WHERE id = {id}";
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand command = new SqlCommand(query, connection);
                try
                {
                    connection.Open();
                    int count = (int)command.ExecuteScalar();
                    if (count == 0)
                    {
                        MessageBox.Show($"ID {id} not found in the database.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
            }

            if (string.IsNullOrWhiteSpace(NameUpTB.Text) || string.IsNullOrWhiteSpace(CodeUpTB.Text) || string.IsNullOrWhiteSpace(BrandUpTB.Text)
                || string.IsNullOrWhiteSpace(UnitPriceUpTB.Text))
            {
                MessageBox.Show("Please enter all fields.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            decimal unitPrice;
            if (!decimal.TryParse(UnitPriceUpTB.Text, out unitPrice))
            {
                MessageBox.Show("Please enter a valid unit price.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            int code;
            if (!int.TryParse(CodeUpTB.Text, out code))
            {
                MessageBox.Show("Please enter a valid code.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            InvModel UpdateItem = new InvModel
            {
                Name = NameUpTB.Text,
                Code = int.Parse(CodeUpTB.Text),
                Brand = BrandUpTB.Text,
                UnitPrice = decimal.Parse(UnitPriceUpTB.Text)
            };

            var client = new RestClient($"https://localhost:7120/api/Item/update/{id}");
            var request = new RestRequest(Method.PUT);
            request.AddJsonBody(UpdateItem);
            var response = client.Execute(request);



            if (response.IsSuccessful)
            {
                // Reload items in data grid view
                LoadItems();
                MessageBox.Show("Item Updated successfully.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                MessageBox.Show("Failed to Update item.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private void LoadData(int id)
        {
            string connectionString = "Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=InvDB;Integrated Security=True;Connect Timeout=60;";
            string query = "SELECT * FROM Inventory WHERE ID = @ID";
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@ID", id);
                    connection.Open();
                    SqlDataReader reader = command.ExecuteReader();
                    DataTable dataTable = new DataTable();
                    dataTable.Load(reader);
                    DataView dataView = new DataView(dataTable);
                    dataGridView1.DataSource = dataView;
                    connection.Close();
                }
            }
        }
        private void button5_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(Idtextbox.Text))
            {
                MessageBox.Show("Please enter an ID.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // Check if the ID entered is valid
            if (!int.TryParse(Idtextbox.Text, out int id))
            {
                MessageBox.Show("Please enter a valid ID.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // Check if the ID exists in the database
            string connectionString = "Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=InvDB;Integrated Security=True;Connect Timeout=60;";
            string query = $"SELECT COUNT(*) FROM Inventory WHERE id = {id}";
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand command = new SqlCommand(query, connection);
                try
                {
                    connection.Open();
                    int count = (int)command.ExecuteScalar();
                    if (count == 0)
                    {
                        MessageBox.Show($"ID {id} not found in the database.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
            }

            // Enable the delete and update buttons if the ID exists in the database
            Deletebtn.Enabled = true;
            Updatebtn.Enabled = true;
            NameUpTB.ReadOnly = false;
            CodeUpTB.ReadOnly = false;
            BrandUpTB.ReadOnly = false;
            UnitPriceUpTB.ReadOnly = false;
            NameUpLbl.Visible = true;
            CodeUpLbl.Visible = true;
            BrandUpLbl.Visible = true;
            UnitPriceUpLbl.Visible = true;

            LoadData(id);


        }




        private void NameUpTB_TextChanged(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            LoginForm l = new LoginForm();
            l.Show();
            this.Hide();
        }

        private void button2_Click_2(object sender, EventArgs e)
        {
            RegisterForm r = new RegisterForm();
            r.Show();
            this.Hide();
        }
    }
}
