﻿using RestSharp;
using System;
using System.Collections.Generic;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using DataLibrary.Data;
using DataLibrary.Database;
using DataLibrary.Models;
using Microsoft.Extensions.Configuration;
using System.Data.SqlClient;
using System.Data;
using System.Text.RegularExpressions;

namespace PartialForm
{
    public partial class RegisterForm : Form
    {
        public RegisterForm()
        {
            InitializeComponent();
        }

        private void LoadItems()
        {
            var client = new RestClient("https://localhost:7120/api/User");
            var request = new RestRequest(Method.GET);
            var response = client.Execute<List<UserModel>>(request);

            if (response.IsSuccessful)
            {
                dataGridView1.DataSource = response.Data;
            }
            else
            {
                MessageBox.Show("Failed to load Users", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void button5_Click(object sender, EventArgs e)
        {
            LoadItems();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form1 f = new Form1();
            f.Show();
            this.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            // Validate textboxes
            if (string.IsNullOrWhiteSpace(UsernameTB.Text) || string.IsNullOrWhiteSpace(FirstnameTB.Text) || string.IsNullOrWhiteSpace(LastnameTB.Text)
                || string.IsNullOrWhiteSpace(PasswordTB.Text))
            {
                MessageBox.Show("Please enter all fields.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            Regex regex = new Regex("^[a-zA-Z]+$"); // only match letters (upper and lower case)
            if (!regex.IsMatch(FirstnameTB.Text))
            {
                MessageBox.Show("Please enter a valid First name.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (!regex.IsMatch(LastnameTB.Text))
            {
                MessageBox.Show("Please enter a valid Last name.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }


            UserModel newUser = new UserModel
            {
                UserName = UsernameTB.Text,
                FirstName = FirstnameTB.Text,
                LastName = LastnameTB.Text,
                Password = PasswordTB.Text
            };

            // Call the AddItem API method using RestSharp
            var client = new RestClient("https://localhost:7120/api/User/register");
            var request = new RestRequest(Method.POST);
            request.AddJsonBody(newUser);
            var response = client.Execute(request);

            if (response.IsSuccessful)
            {
                // Reload items in data grid view
                LoadItems();
                MessageBox.Show("User added successfully.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);

            }
            else
            {
                MessageBox.Show("Failed to add item.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }

        }

        static SqlData GetConnection()
        {
            var builder = new ConfigurationBuilder()
                .SetBasePath(Directory.GetCurrentDirectory())
                .AddJsonFile("appsettings.json");

            IConfiguration config = builder.Build();
            ISqlDataAccess dbAccess = new SqlDataAccess(config);
            SqlData db = new SqlData(dbAccess);

            return db;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(IdTB.Text))
            {
                MessageBox.Show("Please enter an ID.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // Check if the ID entered is valid
            if (!int.TryParse(IdTB.Text, out int id))
            {
                MessageBox.Show("Please enter a valid ID.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // Check if the ID exists in the database
            string connectionString = "Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=InvDB;Integrated Security=True;Connect Timeout=60;";
            string query = $"SELECT COUNT(*) FROM Users WHERE id = {id}";
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand command = new SqlCommand(query, connection);
                try
                {
                    connection.Open();
                    int count = (int)command.ExecuteScalar();
                    if (count == 0)
                    {
                        MessageBox.Show($"ID {id} not found in the database.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                LoadData(id);
            }
        }

        private void LoadData(int id)
        {
            string connectionString = "Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=InvDB;Integrated Security=True;Connect Timeout=60;";
            string query = "SELECT * FROM Users WHERE ID = @ID";
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@ID", id);
                    connection.Open();
                    SqlDataReader reader = command.ExecuteReader();
                    DataTable dataTable = new DataTable();
                    dataTable.Load(reader);
                    DataView dataView = new DataView(dataTable);
                    dataGridView1.DataSource = dataView;
                    connection.Close();
                }
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            // Validate ID textbox
            if (string.IsNullOrWhiteSpace(IdTB.Text))
            {
                MessageBox.Show("Please enter an ID.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            int id;
            if (!int.TryParse(IdTB.Text, out id))
            {
                MessageBox.Show("Please enter a valid ID.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            string connectionString = "Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=InvDB;Integrated Security=True;Connect Timeout=60;";
            string query = $"SELECT COUNT(*) FROM Users WHERE id = {id}";
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand command = new SqlCommand(query, connection);
                try
                {
                    connection.Open();
                    int count = (int)command.ExecuteScalar();
                    if (count == 0)
                    {
                        MessageBox.Show($"ID {id} not found in the database.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
            }


            // Call the DeleteItem API method using RestSharp
            var client = new RestClient($"https://localhost:7120/api/User/delete/{id}");
            var request = new RestRequest(Method.DELETE);
            var response = client.Execute(request);

            if (response.IsSuccessful)
            {
                // Reload items in data grid view
                LoadItems();
                MessageBox.Show("Users deleted successfully.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                MessageBox.Show("Failed to delete User.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}

