﻿CREATE TABLE [dbo].[Inventory]
(
	[Id] INT NOT NULL PRIMARY KEY IDENTITY, 
    [Name] NVARCHAR(50) NOT NULL, 
    [Code] INT NOT NULL, 
    [Brand] NVARCHAR(50) NOT NULL, 
    [UnitPrice] DECIMAL(10, 2) NOT NULL 
)
