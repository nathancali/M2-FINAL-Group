﻿CREATE PROCEDURE [dbo].[spInventory_Insert]
	@name nvarchar(50),
	@code int,
	@brand nvarchar(50),
	@unitPrice decimal
AS
begin
	INSERT INTO dbo.Inventory
	(Name, Code, Brand, UnitPrice)
	VALUES
	(@name, @code, @brand, @unitPrice)
end
