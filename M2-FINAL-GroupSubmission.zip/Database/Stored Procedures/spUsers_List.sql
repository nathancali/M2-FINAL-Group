﻿CREATE PROCEDURE [dbo].[spUsers_List]

AS
begin
	set nocount on;

	SELECT [u].[Id], [u].[UserName], [u].[FirstName], [U].[LastName], [u].[Password]
	FROM dbo.Users u
	
end