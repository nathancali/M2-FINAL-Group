﻿CREATE PROCEDURE [dbo].[spInventory_Delete]
	@id int
AS
BEGIN
	SET NOCOUNT ON;

	DELETE FROM dbo.Inventory
	WHERE Id = @id;

END