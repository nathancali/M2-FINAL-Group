﻿CREATE PROCEDURE [dbo].[spInventory_List]

AS
begin
	set nocount on;

	SELECT [i].[Id], [i].[Name], [i].[Code], [i].[Brand], [i].[UnitPrice]
	FROM dbo.Inventory i
	
end