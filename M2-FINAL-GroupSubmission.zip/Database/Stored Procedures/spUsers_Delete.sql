﻿CREATE PROCEDURE [dbo].[spUsers_Delete]
	@id int
AS
BEGIN
	SET NOCOUNT ON;

	DELETE FROM dbo.Users
	WHERE Id = @id;

END