﻿CREATE PROCEDURE [dbo].[spInventory_Detail]
	@id int
AS
begin
	set nocount on;

	SELECT [i].[Id], [i].[Name], [i].[Code], [i].[Brand], [i].[UnitPrice]
	FROM dbo.Inventory i
		
	WHERE i.Id = @id;
	
end