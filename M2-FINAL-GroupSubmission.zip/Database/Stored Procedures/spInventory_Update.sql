﻿CREATE PROCEDURE [dbo].[spInventory_Update]
    @id int,
    @name nvarchar(50) = null,
    @code int = null,
    @brand nvarchar(50) = null,
    @unitPrice decimal = null
AS
BEGIN
    SET NOCOUNT ON;

    UPDATE dbo.Inventory
    SET
        Name = COALESCE(@name, Name),
        Code = COALESCE(@code, Code),
        Brand = COALESCE(@brand, Brand),
        UnitPrice = COALESCE(@unitPrice, UnitPrice)
    WHERE Id = @id;
END