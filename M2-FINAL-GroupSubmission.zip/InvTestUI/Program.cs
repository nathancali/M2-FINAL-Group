﻿using DataLibrary.Data;
using DataLibrary.Database;
using DataLibrary.Models;
using Microsoft.Extensions.Configuration;

namespace InvTestUI
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello, World!");
            SqlData db = GetConnection();


            ShowInventoryDetails(db);
            


            Console.WriteLine("Press Enter to exit...");
            Console.ReadLine();
        

        }
        static SqlData GetConnection()
        {
            var builder = new ConfigurationBuilder()
                .SetBasePath(Directory.GetCurrentDirectory())
                .AddJsonFile("appsettings.json");

            IConfiguration config = builder.Build();
            ISqlDataAccess dbAccess = new SqlDataAccess(config);
            SqlData db = new SqlData(dbAccess);

            return db;
        }

        private static UserModel GetCurrentUser(SqlData db)
        {
            Console.Write("Username: ");
            string username = Console.ReadLine();

            Console.Write("Password: ");
            string password = Console.ReadLine();

            UserModel user = db.Authenticate(username, password);

            return user;
        }

        public static void Authenticate(SqlData db)
        {
            UserModel user = GetCurrentUser(db);
            if (user == null)
            {
                Console.WriteLine("Invalid Credentials.");

            }
            else
            {
                Console.WriteLine($"Welcome, {user.UserName}");
            }
        }
        public static void Register(SqlData db)
        {
            Console.Write("Enter new username: ");
            var username = Console.ReadLine();
            Console.Write("Enter new password: ");
            var password = Console.ReadLine();
            Console.Write("Enter first name: ");
            var firstName = Console.ReadLine();
            Console.Write("Enter last name: ");
            var lastName = Console.ReadLine();

            db.Register(username, firstName, lastName, password);
        }

        private static void AddInventory(SqlData db)
        {
            UserModel user = GetCurrentUser(db);

            Console.Write("Name of the item: ");
            string name = Console.ReadLine();

            Console.Write("Code: ");
            int code = int.Parse(Console.ReadLine());

            Console.Write("Name of the Brand: ");
            string brand = Console.ReadLine();

            Console.Write("What is the Price: ");
            decimal unitPrice = decimal.Parse(Console.ReadLine());

            InvModel inv = new InvModel
            {
                Name = name,
                Code = code,
                Brand = brand,
                UnitPrice = unitPrice,
            };

            db.AddInventory(inv);
        }

        private static void ListInv(SqlData db)
        {
            List<ListInvModel> Invs = db.ListInvs();
            foreach (ListInvModel inv in Invs)
            {
                Console.WriteLine($"{inv.Id}.   Name: {inv.Name} |  Code: {inv.Code} |  Brand: {inv.Brand} |  Unit Price {inv.UnitPrice} |");
                Console.WriteLine();
            }
        }

        private static void ShowInventoryDetails(SqlData db)
        {
            Console.WriteLine("Enter an Item ID: ");
            int id = Int32.Parse(Console.ReadLine());

            ListInvModel item = db.ShowInventoryDetails(id);
            Console.WriteLine(item.Name);
            Console.WriteLine(item.Code);         
            Console.WriteLine(item.Brand);
            Console.WriteLine(item.UnitPrice);
        }

        private static void DeleteInventory(SqlData db)
        {
            Console.Write("Enter the ID of the item to delete: ");
            int id = int.Parse(Console.ReadLine());
            int rowsAffected = db.DeleteInventory(id);
            if (rowsAffected == 0)
            {
                Console.WriteLine($"Item with ID {id} not found.");
            }
            else
            {
                Console.WriteLine($"Item with ID {id} deleted successfully.");
            }
        }

    }
}