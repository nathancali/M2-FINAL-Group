﻿using DataLibrary.Models;

namespace DataLibrary.Data
{
    public interface ISqlData
    {
        void AddInventory(InvModel inv);
        UserModel Authenticate(string username, string password);
        List<ListInvModel> ListInvs();
        void Register(UserModel user);
        ListInvModel ShowInventoryDetails(int id);
        void DeleteInventory(int id);
        void UpdateInventory(int id, string name = null, int? code = null, string brand = null, decimal? unitPrice = null);
        List<UserModel> ListUsers();
        void DeleteUsers(int id);
    }
}