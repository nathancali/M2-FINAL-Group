﻿using Dapper;
using DataLibrary.Database;
using DataLibrary.Models;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataLibrary.Data
{
    public class SqlData : ISqlData
    {
        private ISqlDataAccess _db;
        private const string connectionStringName = "SqlDb";

        public SqlData(ISqlDataAccess db)
        {
            _db = db;
        }

        public UserModel Authenticate(string username, string password)
        {
            UserModel result = _db.LoadData<UserModel, dynamic>("dbo.spUsers_Authenticate",
                                                                new { username, password },
                                                                connectionStringName,
                                                                true).FirstOrDefault();
            return result;
        }

        public void Register(UserModel user)
        {
            _db.SaveData<dynamic>(
                "dbo.spUsers_Register",
                new { user.UserName, user.FirstName, user.LastName, user.Password },
                connectionStringName,
                true);
        }

        public void AddInventory(InvModel inv)
        {
            _db.SaveData("spInventory_Insert", new { inv.Name, inv.Code, inv.Brand, inv.UnitPrice },
                connectionStringName, true);
        }

        public List<ListInvModel> ListInvs()
        {
            return _db.LoadData<ListInvModel, dynamic>("dbo.spInventory_List", new { }, connectionStringName, true).ToList();
        }

        public ListInvModel ShowInventoryDetails(int id)
        {
            return _db.LoadData<ListInvModel, dynamic>("dbo.spInventory_Detail", new { id }, connectionStringName, true).FirstOrDefault();
        }
        public void DeleteInventory(int id)
        {
            _db.SaveData("dbo.spInventory_Delete", new { Id = id }, connectionStringName, true);
        }

        public void UpdateInventory(InvModel inv)
        {
            _db.SaveData("spInventory_Update", new { inv.Id, inv.Name, inv.Code, inv.Brand, inv.UnitPrice },
                connectionStringName, true);
        }

        public void UpdateInventory(int id, string name = null, int? code = null, string brand = null, decimal? unitPrice = null)
        {
            _db.SaveData<dynamic>(
                "dbo.spInventory_Update",
                new { id, name, code, brand, unitPrice },
                connectionStringName,
                true);
        }

        public List<UserModel> ListUsers()
        {
            return _db.LoadData<UserModel, dynamic>("dbo.spUsers_List", new { }, connectionStringName, true).ToList();
        }

        public void DeleteUsers(int id)
        {
            _db.SaveData("dbo.spUsers_Delete", new { Id = id }, connectionStringName, true);
        }

    }

}

