﻿using PartialProject.Models;

namespace PartialProject.Data
{
    public interface ISqlData
    {
        void AddInventory(InvModel inv);
        UserModel Authenticate(string username, string password);
        List<ListInvModel> ListInvs();
        void Register(string username, string firstName, string lastName, string password);
    }
}