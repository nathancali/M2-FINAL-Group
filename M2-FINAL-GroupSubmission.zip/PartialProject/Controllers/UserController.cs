﻿using DataLibrary.Data;
using DataLibrary.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.IdentityModel.Tokens;
using System;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;

namespace PartialProject.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UserController : ControllerBase
    {
        private readonly IConfiguration _config;
        private readonly ISqlData _db;

        public UserController(IConfiguration config, ISqlData db)
        {
            _config = config;
            _db = db;
        }

        private string GenerateToken(UserModel user)
        {
            var securityKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_config["Jwt:Key"]));
            var credentials = new SigningCredentials(securityKey, SecurityAlgorithms.HmacSha256);
            var claims = new[]
            {
                new Claim(ClaimTypes.NameIdentifier, user.Id.ToString()),
            };
            var token = new JwtSecurityToken(
                _config["Jwt:Issuer"],
                _config["Jwt:Audience"],
                claims,
                expires: DateTime.Now.AddMinutes(15),
                signingCredentials: credentials);

            return new JwtSecurityTokenHandler().WriteToken(token);
        }

        [AllowAnonymous]
        [HttpPost("login")]
        public ActionResult<bool> Login([FromBody] UserLogin login)
        {
            var user = _db.Authenticate(login.UserName, login.Password);

            if (user != null)
            {
                // User is authenticated, return true
                return true;
            }

            // User is not authenticated, return false
            return false;
        }

        [AllowAnonymous]
        [HttpPost("register")]
        public ActionResult Register([FromBody] UserModel user)
        {
            _db.Register(user);
            return Ok("User registered.");
        }

        [AllowAnonymous]
        [HttpDelete]
        [Route("/api/[controller]/delete/{id}")]
        public ActionResult DeleteUser(int id)
        {
            _db.DeleteUsers(id);
            return Ok("User Deleted.");
        }

        [AllowAnonymous]
        [HttpGet]
        public ActionResult ListUsers()
        {
            List<UserModel> User = _db.ListUsers();

            return Ok(User);
        }

    }
}