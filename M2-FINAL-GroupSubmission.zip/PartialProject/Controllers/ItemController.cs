﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using DataLibrary.Data;
using DataLibrary.Models;
using DataLibrary;
using System.Security.Claims;

namespace PartialProject.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ItemController : ControllerBase
    {
        private ISqlData _db;

        public ItemController(ISqlData db)
        {
            _db = db;
        }


        [AllowAnonymous]
        [HttpGet]
        public ActionResult ListInventory()
        {
            List<ListInvModel> inv = _db.ListInvs();

            return Ok(inv);
        }

        // GET: api/items/1
        [AllowAnonymous]
        [HttpGet]
        [Route("/api/[controller]/{id}")]
        public ActionResult<InvModel> GetItem(int id)
        {
            ListInvModel post = _db.ShowInventoryDetails(id);

            return Ok(post);
        }

        // POST: api/items
        [AllowAnonymous]
        [HttpPost]
        [Route("/api/[controller]/add")]
        public ActionResult AddItem([FromBody] InventoryForm form)
        {
            InvModel post = new InvModel();
            post.Name = form.Name;
            post.Code = form.Code;
            post.Brand = form.Brand;
            post.UnitPrice = form.UnitPrice;
            _db.AddInventory(post);

            return Ok("Item Added.");
        }

        private int GetCurrentUserId()
        {
            ClaimsIdentity identity = HttpContext.User.Identity as ClaimsIdentity;

            if (identity != null)
            {
                var userClaims = identity.Claims;
                string id = userClaims.FirstOrDefault(x => x.Type == ClaimTypes.NameIdentifier)?.Value;

                if (id != null)
                {
                    return Convert.ToInt32(id);
                }
            }
            return 0;
        }

        [AllowAnonymous]
        [HttpDelete]
        [Route("/api/[controller]/delete/{id}")]
        public ActionResult DeleteItem(int id)
        {
            _db.DeleteInventory(id);
            return Ok("Item Deleted.");
        }

        [AllowAnonymous]
        [HttpPut]
        [Route("/api/[controller]/update/{id}")]
        public ActionResult UpdateItem(int id, [FromBody] InventoryForm form)
        {
            _db.UpdateInventory(id, form.Name, form.Code, form.Brand, form.UnitPrice);
            return Ok("Item Updated.");
        }



    }
}