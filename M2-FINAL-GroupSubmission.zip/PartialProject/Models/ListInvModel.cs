﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PartialProject.Models
{
    public class ListInvModel
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public int Code { get; set; }
        public string Brand { get; set; }
        public decimal UnitPrice { get; set; }

    }
}
